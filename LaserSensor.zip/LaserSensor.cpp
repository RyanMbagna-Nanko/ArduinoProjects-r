#include "LaserSensor.h"
//#include <Arduino.h>
#include <Wire.h>
#include <LIDARLite.h>
#include <ZumoMotors.h>
#include <Ping.h>

 /*int left = 150;
 int right = 80;
 int center = 120;*/

LIDARLite myLidarLite;

int distance = myLidarLite.distance();  // where is everything?

Lclass::Lclass(){

}

void Lclass::SETUP(){
  
  Serial.begin(115200); // Initialize serial connection to display distance readings
  myLidarLite.begin(0, true); // Set configuration to default and I2C to 400 kHz
  myLidarLite.configure(0); // Change this number to try out alternate configurations
}

void Lclass::RUN(ZumoMotors motors){

 Serial.println(myLidarLite.distance());
  int count = 0;

if(count == 0) {
    for(int i = 0; i < 99; i++)
  {
     Serial.println(myLidarLite.distance(false));
  }
    
    Serial.print(distance);  // print values out on serial monitor
   
    motors.setRightSpeed(4000);  // full speed ahead
    motors.setLeftSpeed(4000);
    
    delay(100);
    
    if(distance <= 10) {    // if the FuzzBot gets too close...
            
    digitalWrite(13, HIGH);  // turn the other way

    motors.setLeftSpeed(-4000);
    motors.setRightSpeed(4000);
 
    delay(100);
                      }
  
  else
  {
    digitalWrite(13, LOW);
    
    motors.setLeftSpeed(4000);
    motors.setRightSpeed(4000);
    count = 1;
}

}
}
boolean Lclass::CRASH(ZumoMotors motors){

if (distance <= 5){
  
   Serial.println("LaserSensor CRASHED!!!!!!.........");
      motors.setRightSpeed(0000);  // stops
      motors.setLeftSpeed(0000);
            delay(100);
            return true;
  }
 return false;
 
Lclass LaserSensor = Lclass();
}
 
 







