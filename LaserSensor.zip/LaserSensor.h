
#ifndef LaserSensor_h
#define LaserSensor_h
#include <Wire.h>
#include <LIDARLite.h>
//#include <Arduino.h>
#include <ZumoMotors.h>


class Lclass
{
   public:
    Lclass();
    void SETUP();
    void RUN(ZumoMotors);
    boolean CRASH(ZumoMotors);

};

extern Lclass LaserSensor;

#endif
