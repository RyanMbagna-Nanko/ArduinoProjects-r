//*

#ifndef PingSensor_h
#define PingSensor_h
//#include "Arduino.h"
#include "Ping.h"
#include <Ping.h>
#include <Arduino.h>
#include <ZumoMotors.h>



class Pclass{
  public:
    Pclass();
    void SETUP();
    void RUN(ZumoMotors);
    boolean CRASH(ZumoMotors);
 /*
    Ping(int pin);
    Ping(int pin, double in, double cm);
    void fire();
    int microseconds();
    double inches();
    double centimeters();
  private:
    int _pin;
    double _in;
    double _cm;
    long _duration;
 */
};

extern Pclass PingSensor;

#endif

//*/
