
#include "PingSensor.h"
#include <Ping.h>
#include <Wire.h>
//#include <Arduino.h>
#include <ZumoMotors.h>

const uint8_t ping_pin = 8;
 Ping ping = Ping(4);
   /*int left = 150;
   int right = 80;
   int center = 120;
   int count = 0;*/
ZumoMotors motors;
     int inches = ping.inches();  // where is everything?
    int cm = ping.centimeters();
    int mseconds = ping.microseconds();
 
Pclass::Pclass(){
}

void Pclass::SETUP(){

pinMode(13, OUTPUT);
  Serial.begin(9600);
}



void Pclass::RUN(ZumoMotors motors){
  int count = 0;

  if(count == 0) {
    for(int i = 0; i<5; i++) {    // do this 5 times
    ping.fire();
    
     
    Serial.print(inches);  // print values out on serial monitor
    Serial.print(" , ");
    Serial.print(cm);
    Serial.print(" , ");
    Serial.println(mseconds);

    motors.setRightSpeed(4000);  // full speed ahead
    motors.setLeftSpeed(4000);
    
    delay(100);
    
    if(inches <= 10) {    // if the FuzzBot gets too close...
            
    digitalWrite(13, HIGH);  // turn the other way

    motors.setLeftSpeed(-4000);
    motors.setRightSpeed(4000);
 
    delay(100);
  }else{
    digitalWrite(13, LOW);
    
    motors.setLeftSpeed(4000);
    motors.setRightSpeed(4000);
    count = 1;
}
    }}}
    
boolean Pclass::CRASH(ZumoMotors motors){

  if (inches == 0) 
  {
      Serial.println("PingSensor CRASHED!!!!!!.........");
      motors.setRightSpeed(0000);  // full speed ahead
      motors.setLeftSpeed(0000);
            delay(100);
return true;
    }
    return false;
  }
 
/*
long microsecondsToInches(long microseconds) {
  // According to Parallax's datasheet for the PING))), there are
  // 73.746 microseconds per inch (i.e. sound travels at 1130 feet per
  // second).  This gives the distance travelled by the PingSensor, outbound
  // and return, so we divide by 2 to get the distance of the obstacle.
  // See: http://www.parallax.com/dl/docs/prod/acc/28015-PING-v1.3.pdf
  return microseconds / 74 / 2;
}

long microsecondsToCentimeters(long microseconds) {
  // The speed of sound is 340 m/s or 29 microseconds per centimeter.
  // The PingSensor travels out and back, so to find the distance of the
  // object we take half of the distance travelled.
  return microseconds / 29 / 2;
}
}*/

Pclass PingSensor = Pclass();
  

//*/
